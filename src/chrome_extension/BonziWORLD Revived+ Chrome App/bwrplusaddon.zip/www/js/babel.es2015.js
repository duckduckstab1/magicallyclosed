"use strict";

var ass = "memem";
//# sourceMappingURL=babel.es2015.js.map
